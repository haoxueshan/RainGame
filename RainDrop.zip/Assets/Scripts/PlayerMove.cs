﻿using UnityEngine;

public class PlayerMove : MonoBehaviour
{
    public float speed = 5f;
    public float minX = -8f;
    public float maxX = 8f;

    private bool gameStopped = false;

    void Update()
    {
        // 游戏已经停止 → 不再允许移动
        if (gameStopped) return;

        float h = Input.GetAxisRaw("Horizontal");
        Vector3 pos = transform.position;

        pos.x += h * speed * Time.deltaTime;
        pos.x = Mathf.Clamp(pos.x, minX, maxX);

        transform.position = pos;
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Rain"))
        {
            Debug.Log("Rain hit player → Stop Game");

            // 撞到后把雨滴也停住：直接销毁（简单粗暴）
            Destroy(other.gameObject);

            // 可选：把玩家变灰，看起来像被“冻住”
            var sr = GetComponent<SpriteRenderer>();
            if (sr != null)
            {
                sr.color = new Color(0.5f, 0.5f, 0.5f, 1f);
            }

            // 第一：暂停整个 Unity 游戏
            Time.timeScale = 0f;

            // 第二：标记自己为停止状态（防止暂停恢复后还继续）
            gameStopped = true;
        }
    }
}
