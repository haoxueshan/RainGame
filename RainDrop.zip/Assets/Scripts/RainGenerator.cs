﻿using UnityEngine;

public class RainGenerator : MonoBehaviour
{
    public GameObject rainPrefab;   // 雨滴预制体
    public float spawnInterval = 0.5f; // 生成间隔（秒）

    public float minX = -8f;        // 随机生成的 X 最小值
    public float maxX = 8f;         // 随机生成的 X 最大值
    public float spawnY = 6f;       // 生成的 Y 高度（在屏幕上方）

    private float timer = 0f;

    void Update()
    {
        timer += Time.deltaTime;

        if (timer >= spawnInterval)
        {
            timer = 0f;
            SpawnOne();
        }
    }

    void SpawnOne()
    {
        if (rainPrefab == null) return;

        float x = Random.Range(minX, maxX);
        Vector3 pos = new Vector3(x, spawnY, 0);
        Instantiate(rainPrefab, pos, Quaternion.identity);
    }
}
