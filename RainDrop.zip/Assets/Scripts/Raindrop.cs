﻿using UnityEngine;

public class Raindrop : MonoBehaviour
{
    public float fallSpeed = 3f;   // 下落速度
    public float destroyY = -6f;   // 掉出屏幕后销毁的 Y 值

    void Update()
    {
        // 每帧向下移动
        transform.Translate(Vector3.down * fallSpeed * Time.deltaTime);

        // 如果掉到屏幕下方，看不到了就销毁
        if (transform.position.y < destroyY)
        {
            Destroy(gameObject);
        }
    }
}
